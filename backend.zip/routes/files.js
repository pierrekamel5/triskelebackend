/* const express=require('express');
const router=express.Router();
const path = require('path');

const jwt=require('jsonwebtoken');
const passport=require('passport');

const config=require('../config/database');
const Client=require('../models/client');


router.get('/icon',(req,res,next)=>{
    return res.status(200).json({status:"OK"});
});

module.exports=router; */