module.exports={
    database:'mongodb+srv://admin:admin@cluster0.qummx.mongodb.net/myFirstDatabase?retryWrites=true&w=majority',
    secret:"KillMePlease"
}